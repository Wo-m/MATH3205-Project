Instructions:

Each instance consists of 4 files
- the job_inst file specifies the jobs. 
- the depot_info file determines the capacity of the depot for each period (a period is a line)
- the max_travel file denotes for each period (each line) the max travel time of the vessels
- the gen_info file denotes general info and the vehicle info. 

The travel and cost parameters of the vehicle are used to transfer distance to cost and to time, by respectively multiplying and dividing the distance, respectively.


